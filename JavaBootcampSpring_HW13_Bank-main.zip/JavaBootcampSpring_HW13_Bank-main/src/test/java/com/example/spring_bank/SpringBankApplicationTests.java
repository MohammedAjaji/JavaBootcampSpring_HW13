package com.example.spring_bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
