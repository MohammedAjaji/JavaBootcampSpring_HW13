package com.example.spring_tasktracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringTaskTrackerApplicationTests {

    @Test
    void contextLoads() {
    }

}
