package com.example.spring_tasktracker.ApiResponse;

import lombok.AllArgsConstructor;
import lombok.Data;

@AllArgsConstructor
@Data
public class ApiResponse {

    private String messsage;

}
